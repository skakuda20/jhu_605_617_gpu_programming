#!/bin/bash
./build/convolution data/input.png data/output.png blur
